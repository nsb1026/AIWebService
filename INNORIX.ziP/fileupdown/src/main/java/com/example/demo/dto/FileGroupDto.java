package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileGroupDto {
    private List<FileMetaDto> addedFiles = new ArrayList<>();
    private List<Long> deletedFileIds = new ArrayList<>();
}
