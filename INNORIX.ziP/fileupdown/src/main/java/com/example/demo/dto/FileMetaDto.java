package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ============================================================================================
 * 📌 파일 메타데이터 정보 전달 객체 (FileMetaDto)
 * ============================================================================================
 * [핵심 필드: rowState]
 * - "C" (Create) : 화면에서 새로 업로드되어 추가된 신규 파일
 * - "U" (Update) : 기존 DB에 저장되어 유지되거나 변경된 파일
 * - "D" (Delete) : 화면에서 삭제 선택되어 서버 삭제 대상이 된 파일
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileMetaDto {
    private Long fileId;            // 파일 PK (저장된 파일 고유 식별자)
    private Long targetId;          // 마스터 테이블 PK (게시글 ID 등)
    private String category;        // 파일 구분 카테고리 / 컴포넌트 식별자 (예: attachDocFiles, attachImgFiles)
    
    // ★ 공통 상태 구분자: "C" (신규 추가), "U" (수정/유지), "D" (삭제 요청)
    private String rowState;        
    
    private String originalName;    // 사용자 원본 파일명 (예: 사업계획서.pdf)
    private String savedName;       // 서버 물리 저장 파일명 (UUID 기반 고유 파일명)
    private String filePath;        // 서버 물리 저장 절대/상대 경로
    private String fileExtension;   // 파일 확장자 (pdf, xlsx, png 등)
    private Long fileSize;          // 파일 용량 (Byte)
    private String formattedSize;   // MB / KB 포맷팅된 파일 크기 문자열
    private String contentType;     // MIME 타입 (application/pdf 등)
    private String regDate;         // 최초 등록일시 (yyyy-MM-dd HH:mm:ss)
    private String uploadStatus;    // 업로드 상태 (UPLOADED, TEMP_UPLOADED 등)
}
