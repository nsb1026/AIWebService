package com.example.demo.dto;

import lombok.Data;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================================================
 * 📌 메인 게시글 저장 폼 통합 요청 객체 (BoardFormRequest)
 * ============================================================================================
 */
@Data
public class BoardFormRequest {
    private Long id;                        // 게시글 ID (마스터 PK)
    private String title;                   // 게시글 제목
    private String content;                 // 게시글 내용
    private String writer;                  // 작성자 이름

    // 로직에서 활용 가능한 파일 개수 통계 필드
    private Integer newFileCount;           // 신규 추가된 파일 개수 (C)
    private Integer delFileCount;           // 삭제된 파일 개수 (D)
    private Integer totalFileCount;         // 최종 남아있는 활성 파일 개수 (C + U)

    /**
     * ★ [공통 통합 파일 리스트]
     * - 각 FileMetaDto 내부의 rowState ("C": 추가, "U": 유지, "D": 삭제)
     */
    private List<FileMetaDto> fileList = new ArrayList<>();

    // 하위 호환 필드
    private Map<String, FileGroupDto> fileGroups = new HashMap<>();
    private List<FileMetaDto> addedFiles = new ArrayList<>();
    private List<Long> deletedFileIds = new ArrayList<>();
}
