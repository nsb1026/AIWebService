package com.example.demo.controller;

import com.example.demo.dto.FileMetaDto;
import com.example.demo.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * ============================================================================================
 * 📌 파일 처리 전용 REST API Controller (FileController)
 * ============================================================================================
 * [제공 엔드포인트]
 * 1. POST /api/files/upload           : Innorix 및 표준 HTML5 파일 업로드 요청 처리
 * 2. GET  /api/files                  : targetId 및 카테고리별 첨부파일 목록 조회
 * 3. GET  /api/files/download/{fileId}: 특정 첨부파일 다운로드
 */
@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
public class FileController {

    private final FileStorageService fileStorageService;

    /**
     * Innorix / 표준 HTML5 파일 업로드 핸들러
     * @param file 업로드 파일 (MultipartFile)
     * @param category 멀티 파일 컴포넌트 식별자 (예: attachDocFiles)
     * @return 저장된 파일 메타데이터 (FileMetaDto)
     */
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "category", required = false) String category) {
        try {
            if (file == null || file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "업로드할 파일이 존재하지 않습니다."));
            }
            // 서비스 레이어 호출하여 물리적 저장소에 파일 저장 및 DTO 반환
            FileMetaDto fileMeta = fileStorageService.storeFile(file, category);
            return ResponseEntity.ok(fileMeta);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "서버 저장 실패: " + e.getMessage()));
        }
    }

    /**
     * 특정 targetId(게시글 ID 등) 및 category(컴포넌트 식별자)에 연결된 파일 목록 조회
     * @param targetId 마스터 게시글 ID
     * @param category 파일 구분 카테고리
     * @return 파일 메타데이터 목록 (rowState = "U" 기본 세팅됨)
     */
    @GetMapping
    public ResponseEntity<List<FileMetaDto>> getFileList(
            @RequestParam(value = "targetId", required = false) Long targetId,
            @RequestParam(value = "category", required = false) String category) {
        List<FileMetaDto> files = fileStorageService.getFilesByTargetIdAndCategory(targetId, category);
        return ResponseEntity.ok(files);
    }

    /**
     * 특정 파일 ID 기반 물리 파일 다운로드
     * @param fileId 다운로드 대상 파일 PK
     * @return 바이너리 파일 리소스 (Content-Disposition attachment 적용)
     */
    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable("fileId") Long fileId) {
        try {
            FileMetaDto meta = fileStorageService.getFileById(fileId);
            Resource resource = fileStorageService.loadFileAsResource(fileId);

            // 파일명 한글 깨짐 방지 인코딩 처리
            String encodedFileName = URLEncoder.encode(meta.getOriginalName(), StandardCharsets.UTF_8)
                    .replaceAll("\\+", "%20");

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFileName + "\"; filename*=UTF-8''" + encodedFileName)
                    .body(resource);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
