package com.example.demo.service;

import com.example.demo.dto.FileGroupDto;
import com.example.demo.dto.FileMetaDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================================================
 * 📌 파일 처리 및 서버 물리 저장소 관리 서비스 (FileStorageService)
 * ============================================================================================
 */
@Service
public class FileStorageService {

    @Value("${file.upload-dir:C:/uploads/fileupdown}")
    private String uploadDir;

    private final Map<Long, FileMetaDto> fileDatabase = new ConcurrentHashMap<>();
    private final AtomicLong fileIdSequence = new AtomicLong(100);

    public FileStorageService() {
        fileDatabase.put(1L, FileMetaDto.builder()
                .fileId(1L)
                .targetId(1L)
                .category("attachDocFiles")
                .rowState("U")
                .originalName("사업계획서_2026.pdf")
                .savedName("sample_1.pdf")
                .filePath("sample_1.pdf")
                .fileExtension("pdf")
                .fileSize(2457600L)
                .formattedSize("2.34 MB")
                .contentType("application/pdf")
                .regDate(LocalDateTime.now().minusDays(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .uploadStatus("UPLOADED")
                .build());

        fileDatabase.put(2L, FileMetaDto.builder()
                .fileId(2L)
                .targetId(1L)
                .category("attachImgFiles")
                .rowState("U")
                .originalName("현장사진_01.png")
                .savedName("sample_2.png")
                .filePath("sample_2.png")
                .fileExtension("png")
                .fileSize(512000L)
                .formattedSize("500 KB")
                .contentType("image/png")
                .regDate(LocalDateTime.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .uploadStatus("UPLOADED")
                .build());
    }

    public FileMetaDto storeFile(MultipartFile file, String category) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("업로드할 파일 데이터가 비어있습니다.");
        }

        String originalName = file.getOriginalFilename();
        if (originalName == null || originalName.trim().isEmpty()) {
            originalName = "file_" + System.currentTimeMillis();
        }

        String ext = "";
        int dotIdx = originalName.lastIndexOf(".");
        if (dotIdx > 0) {
            ext = originalName.substring(dotIdx + 1).toLowerCase();
        }

        String uuidName = UUID.randomUUID().toString() + (ext.isEmpty() ? "" : "." + ext);

        File dir = new File(uploadDir);
        try {
            if (!dir.exists()) {
                dir.mkdirs();
            }
        } catch (Exception e) {
            dir = new File(System.getProperty("user.dir") + "/uploads");
            if (!dir.exists()) dir.mkdirs();
        }

        Path targetPath = dir.toPath().resolve(uuidName);
        try {
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            File fallbackDir = new File(System.getProperty("user.dir") + "/uploads");
            if (!fallbackDir.exists()) fallbackDir.mkdirs();
            targetPath = fallbackDir.toPath().resolve(uuidName);
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        }

        long size = file.getSize();
        Long newFileId = fileIdSequence.incrementAndGet();

        FileMetaDto meta = FileMetaDto.builder()
                .fileId(newFileId)
                .category(category != null ? category : "default")
                .rowState("C")
                .originalName(originalName)
                .savedName(uuidName)
                .filePath(targetPath.toString())
                .fileExtension(ext)
                .fileSize(size)
                .formattedSize(formatFileSize(size))
                .contentType(file.getContentType())
                .regDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .uploadStatus("TEMP_UPLOADED")
                .build();

        fileDatabase.put(newFileId, meta);
        return meta;
    }

    public Map<String, Integer> processFiles(Long targetId, List<FileMetaDto> fileList) {
        Map<String, Integer> resultCount = new HashMap<>();
        int createdCount = 0;
        int updatedCount = 0;
        int deletedCount = 0;

        if (fileList == null || fileList.isEmpty()) {
            resultCount.put("created", 0);
            resultCount.put("updated", 0);
            resultCount.put("deleted", 0);
            return resultCount;
        }

        for (FileMetaDto dto : fileList) {
            String state = dto.getRowState();
            if (state == null) state = "U";
            state = state.toUpperCase();

            switch (state) {
                case "C":
                case "CREATE":
                case "INSERT":
                    saveNewFile(targetId, dto);
                    createdCount++;
                    break;

                case "D":
                case "DELETE":
                    deleteFile(dto.getFileId());
                    deletedCount++;
                    break;

                case "U":
                case "UPDATE":
                    updateFile(targetId, dto);
                    updatedCount++;
                    break;
            }
        }

        resultCount.put("created", createdCount);
        resultCount.put("updated", updatedCount);
        resultCount.put("deleted", deletedCount);
        return resultCount;
    }

    /**
     * ============================================================================================
     * 📌 [★ 신규 공통 기능] 백엔드 파일 리스트의 신규추가(C), 기존/수정(U), 삭제(D) 상태별 개수 파악 함수
     * ============================================================================================
     */
    public Map<String, Integer> calculateFileStateCounts(List<FileMetaDto> fileList) {
        Map<String, Integer> result = new HashMap<>();
        int createdCount = 0;
        int updatedCount = 0;
        int deletedCount = 0;

        if (fileList != null) {
            for (FileMetaDto f : fileList) {
                if (f == null) continue;
                String state = f.getRowState() != null ? f.getRowState().toUpperCase() : "U";
                if ("C".equals(state) || "CREATE".equals(state) || "INSERT".equals(state)) {
                    createdCount++;
                } else if ("D".equals(state) || "DELETE".equals(state)) {
                    deletedCount++;
                } else {
                    updatedCount++;
                }
            }
        }

        result.put("totalCount", (fileList != null ? fileList.size() : 0));
        result.put("activeCount", createdCount + updatedCount);
        result.put("createdCount", createdCount); // C (신규추가 개수)
        result.put("updatedCount", updatedCount); // U (기존/수정 개수)
        result.put("deletedCount", deletedCount); // D (삭제 개수)

        return result;
    }

    private void saveNewFile(Long targetId, FileMetaDto dto) {
        Long fId = dto.getFileId();
        if (fId == null) {
            fId = fileIdSequence.incrementAndGet();
            dto.setFileId(fId);
        }
        dto.setTargetId(targetId);
        dto.setRowState("U");
        dto.setUploadStatus("UPLOADED");
        if (dto.getRegDate() == null) {
            dto.setRegDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        }
        if (dto.getFormattedSize() == null && dto.getFileSize() != null) {
            dto.setFormattedSize(formatFileSize(dto.getFileSize()));
        }
        fileDatabase.put(fId, dto);
    }

    private void deleteFile(Long fileId) {
        if (fileId == null) return;
        FileMetaDto removed = fileDatabase.remove(fileId);
        if (removed != null && removed.getSavedName() != null) {
            try {
                Path path = Paths.get(uploadDir).resolve(removed.getSavedName());
                Files.deleteIfExists(path);
            } catch (Exception ignored) {}
        }
    }

    private void updateFile(Long targetId, FileMetaDto dto) {
        if (dto.getFileId() != null && fileDatabase.containsKey(dto.getFileId())) {
            FileMetaDto existing = fileDatabase.get(dto.getFileId());
            existing.setTargetId(targetId);
            if (dto.getCategory() != null) existing.setCategory(dto.getCategory());
        }
    }

    public List<FileMetaDto> getFilesByTargetIdAndCategory(Long targetId, String category) {
        if (targetId == null) return Collections.emptyList();
        List<FileMetaDto> result = new ArrayList<>();
        for (FileMetaDto dto : fileDatabase.values()) {
            if (targetId.equals(dto.getTargetId())) {
                if (category == null || category.trim().isEmpty() || category.equalsIgnoreCase(dto.getCategory())) {
                    dto.setRowState("U");
                    result.add(dto);
                }
            }
        }
        return result;
    }

    public Resource loadFileAsResource(Long fileId) throws MalformedURLException {
        FileMetaDto meta = fileDatabase.get(fileId);
        if (meta == null) {
            throw new RuntimeException("파일을 찾을 수 없습니다. ID: " + fileId);
        }
        Path filePath = Paths.get(uploadDir).resolve(meta.getSavedName()).normalize();
        Resource resource = new UrlResource(filePath.toUri());
        if (resource.exists() && resource.isReadable()) {
            return resource;
        } else {
            Path fallbackPath = Paths.get(System.getProperty("user.dir") + "/uploads").resolve(meta.getSavedName()).normalize();
            Resource fallbackResource = new UrlResource(fallbackPath.toUri());
            if (fallbackResource.exists() && fallbackResource.isReadable()) {
                return fallbackResource;
            }
            throw new RuntimeException("서버 물리 경로에 파일이 존재하지 않습니다: " + meta.getOriginalName());
        }
    }

    public FileMetaDto getFileById(Long fileId) {
        return fileDatabase.get(fileId);
    }

    public void processFileGroups(Long targetId, Map<String, FileGroupDto> fileGroups) {
        if (fileGroups == null || fileGroups.isEmpty()) return;
        List<FileMetaDto> combinedList = new ArrayList<>();

        for (Map.Entry<String, FileGroupDto> entry : fileGroups.entrySet()) {
            String category = entry.getKey();
            FileGroupDto group = entry.getValue();

            if (group != null) {
                if (group.getAddedFiles() != null) {
                    for (FileMetaDto f : group.getAddedFiles()) {
                        f.setCategory(category);
                        f.setRowState("C");
                        combinedList.add(f);
                    }
                }
                if (group.getDeletedFileIds() != null) {
                    for (Long dId : group.getDeletedFileIds()) {
                        FileMetaDto delDto = FileMetaDto.builder()
                                .fileId(dId)
                                .rowState("D")
                                .build();
                        combinedList.add(delDto);
                    }
                }
            }
        }
        processFiles(targetId, combinedList);
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        char pre = "KMGTPE".charAt(exp - 1);
        return String.format(Locale.US, "%.2f %cB", bytes / Math.pow(1024, exp), pre);
    }
}
