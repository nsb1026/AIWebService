package com.example.demo.controller;

import com.example.demo.dto.BoardFormRequest;
import com.example.demo.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * ============================================================================================
 * 📌 메인 게시글 및 통합 데이터 처리 Controller (BoardController)
 * ============================================================================================
 */
@Controller
@RequiredArgsConstructor
public class BoardController {

    private final FileStorageService fileStorageService;

    @GetMapping({"/", "/board/form"})
    public String boardForm(@RequestParam(value = "id", required = false) Long id, Model model) {
        model.addAttribute("targetId", id != null ? id : 1L);
        return "board/boardForm";
    }

    /**
     * 화면 Form 저장 시 파일 개수(신규/삭제/총개수)를 로직에서 수신 및 DB 처리
     */
    @PostMapping("/api/board/save")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> saveBoard(@RequestBody BoardFormRequest request) {
        Map<String, Object> response = new HashMap<>();

        Long boardId = request.getId();
        if (boardId == null) {
            boardId = 1001L;
        }

        // 1. 백엔드 서비스에서 fileList 분석하여 상태별 파일 개수 파악
        Map<String, Integer> stateStats = fileStorageService.calculateFileStateCounts(request.getFileList());
        
        int createdCount = stateStats.get("createdCount"); // 신규 추가 수
        int deletedCount = stateStats.get("deletedCount"); // 삭제 수
        int activeCount = stateStats.get("activeCount");   // 최종 활성 파일 수

        // 로직 처리 (예: 마스터 게시글 테이블의 file_cnt 컬럼에 activeCount 저장 등)
        System.out.println("====== [저장 비즈니스 로직 연동 확인] ======");
        System.out.println("게시글 ID: " + boardId);
        System.out.println("신규 추가 파일 수: " + createdCount);
        System.out.println("삭제 요청 파일 수: " + deletedCount);
        System.out.println("최종 게시글 파일 수: " + activeCount);
        System.out.println("==========================================");

        // 2. 물리 파일 및 DB 레코드 공통 이력 처리
        fileStorageService.processFiles(boardId, request.getFileList());

        response.put("success", true);
        response.put("message", "게시글 저장 완료 (파일 개수 로직 연동 완료)");
        response.put("boardId", boardId);
        response.put("savedAddedFilesCount", createdCount);
        response.put("deletedFilesCount", deletedCount);
        response.put("totalActiveFilesCount", activeCount);

        return ResponseEntity.ok(response);
    }
}
