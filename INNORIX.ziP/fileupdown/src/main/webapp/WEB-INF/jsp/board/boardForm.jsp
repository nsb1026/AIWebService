<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>Spring Boot + Innorix (저장 로직에서 파일 개수 활용 예시)</title>
    <style>
        body {
            font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f8fafc;
            margin: 0;
            padding: 40px 20px;
            color: #1e293b;
        }

        .main-container {
            max-width: 960px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            padding: 32px;
        }

        .page-title {
            font-size: 22px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 2px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-title {
            font-size: 16px;
            font-weight: 700;
            color: #1e293b;
            margin-top: 28px;
            margin-bottom: 8px;
            padding-left: 8px;
            border-left: 4px solid #2563eb;
        }

        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 14px; font-weight: 600; color: #334155; margin-bottom: 6px; }

        .form-control {
            width: 100%;
            padding: 10px 14px;
            font-size: 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            box-sizing: border-box;
            outline: none;
        }

        textarea.form-control { height: 80px; resize: vertical; }

        .form-actions {
            margin-top: 32px;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .btn-submit {
            padding: 10px 24px;
            font-size: 14px;
            font-weight: 600;
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .btn-submit:hover { background-color: #1d4ed8; }

        .btn-reset {
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 500;
            background-color: #f1f5f9;
            color: #475569;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="main-container">
    <div class="page-title">
        <span>📝 게시물 (저장 로직에서 파일 개수 활용 연동)</span>
        <span style="font-size: 13px; font-weight: normal; color: #64748b;">Target ID: ${targetId}</span>
    </div>

    <!-- 메인 게시글 입력 폼 -->
    <form id="mainBoardForm">
        <input type="hidden" id="boardId" name="id" value="${targetId}" />

        <div class="form-group">
            <label class="form-label" for="title">게시글 제목</label>
            <input type="text" id="title" name="title" class="form-control" value="2026년도 사업승인 신청서" />
        </div>

        <div class="form-row" style="display: flex; gap: 16px;">
            <div class="form-group" style="flex: 1;">
                <label class="form-label" for="writer">작성자</label>
                <input type="text" id="writer" name="writer" class="form-control" value="홍길동 팀장" />
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="content">내용</label>
            <textarea id="content" name="content" class="form-control">저장 로직에서 공통 함수로 파일 개수를 가져와 검증 및 DB 저장을 수행합니다.</textarea>
        </div>

        <!-- 파일 컴포넌트 1 -->
        <div class="section-title">📂 파일 그룹 1: 필수 증빙 서류</div>
        <jsp:include page="/WEB-INF/jsp/common/fileComponent.jsp">
            <jsp:param name="name" value="attachDocFiles" />
            <jsp:param name="formId" value="mainBoardForm" />
            <jsp:param name="title" value="📄 증빙서류 (PDF, HWP, DOCX)" />
            <jsp:param name="mode" value="EDIT" />
        </jsp:include>

        <!-- 파일 컴포넌트 2 -->
        <div class="section-title" style="margin-top: 36px;">📂 파일 그룹 2: 현장 사진 및 기타 문서</div>
        <jsp:include page="/WEB-INF/jsp/common/fileComponent.jsp">
            <jsp:param name="name" value="attachImgFiles" />
            <jsp:param name="formId" value="mainBoardForm" />
            <jsp:param name="title" value="🖼️ 현장 사진 및 기타 첨부" />
            <jsp:param name="mode" value="EDIT" />
        </jsp:include>

        <!-- 폼 하단 버튼 -->
        <div class="form-actions">
            <button type="button" class="btn-reset" onclick="location.reload()">취소 / 새로고침</button>
            <button type="button" class="btn-submit" onclick="submitMainForm()">💾 저장 (로직에서 개수 검증 및 전송)</button>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const targetId = document.getElementById('boardId').value;
        if (targetId) {
            FileComponentManager.loadAll('mainBoardForm', targetId);
        }
    });

    /**
     * ============================================================================================
     * 📌 [★ 저장 비즈니스 로직 예시]
     * 저장 시 공통 함수(getAllFileStateCounts)를 호출하여 파일 개수 값을 가져와 로직에 활용
     * ============================================================================================
     */
    function submitMainForm() {
        const title = document.getElementById('title').value.trim();
        if (!title) {
            alert('게시글 제목을 입력해주세요.');
            return;
        }

        // 1. [★ 로직 활용 1] 공통 함수를 호출하여 파일 개수 정보 추출
        const fileStats = FileComponentManager.getAllFileStateCounts('mainBoardForm');

        // 추출된 개수 변수:
        const createdCount = fileStats.createdCount; // 신규 추가 수
        const deletedCount = fileStats.deletedCount; // 삭제 수
        const activeCount = fileStats.activeCount;   // 최종 남아있는 활성 파일 수

        console.log('--- [저장 로직 내 파일 개수 정보] ---');
        console.log('신규 추가 개수:', createdCount);
        console.log('삭제 선택 개수:', deletedCount);
        console.log('최종 남을 파일 개수:', activeCount);

        // 2. [★ 로직 활용 2] 업무 로직 조건 검사 (예: 필수 증빙서류 그룹 개수 체크 등)
        const docGroupStats = FileComponentManager.getFileStateCounts('attachDocFiles');
        if (docGroupStats.activeCount === 0) {
            if (!confirm('필수 증빙 서류가 등록되지 않았습니다. 그래도 저장하시겠습니까?')) {
                return;
            }
        }

        // 3. [★ 로직 활용 3] payload 에 파일 개수 통계값을 담아서 백엔드로 전송
        const payload = {
            id: document.getElementById('boardId').value ? parseInt(document.getElementById('boardId').value) : null,
            title: title,
            writer: document.getElementById('writer').value,
            content: document.getElementById('content').value,
            
            // 로직에서 활용하기 위해 파일 개수 통계값 세팅
            newFileCount: createdCount,
            delFileCount: deletedCount,
            totalFileCount: activeCount,
            
            // 공통 파일 통합 리스트 (rowState C, U, D 포함)
            fileList: FileComponentManager.getAllFileList('mainBoardForm')
        };

        // 4. 서버 저장 요청
        fetch('/api/board/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(`✅ ${data.message}\n\n[처리 내역]\n- 신규 저장: ${data.savedAddedFilesCount}개\n- 삭제 완료: ${data.deletedFilesCount}개\n- 최종 파일 수: ${data.totalActiveFilesCount}개`);
                FileComponentManager.loadAll('mainBoardForm', payload.id);
            }
        });
    }
</script>

</body>
</html>
