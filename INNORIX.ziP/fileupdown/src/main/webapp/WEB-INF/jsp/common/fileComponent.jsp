<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!-- ============================================================================================ -->
<!-- 📌 공통 파일 관리 JSP Component (Innorix 연동 및 파일 업로드/목록 관리 모듈)                      -->
<!-- ============================================================================================ -->
<!-- 
  [컴포넌트 기능 요약]
  1. Innorix 전용 업로드 모듈 연동 및 HTML5 표준 File Input Fallback 지원
  2. 한 화면 내 복수의 파일 컴포넌트 동시 배치 지원 (name / formId 기반 격리)
  3. VIEW / EDIT 화면 모드 구분 제어 (VIEW: 조회 및 다운로드 전용, EDIT: 내 PC 업로드 및 선택 삭제 전용)
  4. 파일유형별 오피스/이미지/압축/코드 전용 벡터 SVG 아이콘 자동 매핑
  5. 추가(C), 유지/수정(U), 삭제(D) 상태를 가지는 단일 통합 데이터(rowState) 관리 지원
  6. [NEW] 신규추가(C), 기존/수정(U), 삭제(D) 상태별 파일 개수 파악 공통 함수 (getFileStateCounts) 제공
-->

<%
    String compName = request.getParameter("name");
    if (compName == null || compName.trim().isEmpty()) {
        compName = "fileComp_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 1000);
    }
    
    String formId = request.getParameter("formId");
    if (formId == null) formId = "";
    
    String compTitle = request.getParameter("title");
    if (compTitle == null || compTitle.trim().isEmpty()) {
        compTitle = "📎 첨부파일 목록";
    }

    String mode = request.getParameter("mode");
    if (mode == null || mode.trim().isEmpty()) {
        mode = "EDIT";
    } else {
        mode = mode.toUpperCase();
    }
    
    request.setAttribute("compName", compName);
    request.setAttribute("formId", formId);
    request.setAttribute("compTitle", compTitle);
    request.setAttribute("mode", mode);
%>

<style>
  .file-component-container {
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    background-color: #ffffff;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-top: 15px;
  }

  .file-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 1px solid #edf2f7;
  }

  .file-toolbar .title {
    font-size: 15px;
    font-weight: 600;
    color: #2d3748;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .file-btn-group { display: flex; gap: 8px; }

  .btn-file-action {
    padding: 6px 14px;
    font-size: 13px;
    font-weight: 500;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .btn-add-file { background-color: #2563eb; color: #ffffff; }
  .btn-add-file:hover { background-color: #1d4ed8; }

  .btn-delete-file { background-color: #ef4444; color: #ffffff; }
  .btn-delete-file:hover { background-color: #dc2626; }

  .btn-download-file { background-color: #059669; color: #ffffff; }
  .btn-download-file:hover { background-color: #047857; }

  .innorix-wrapper {
    margin-bottom: 12px;
    border: 1px dashed #cbd5e1;
    border-radius: 6px;
    background-color: #f8fafc;
    min-height: 50px;
    padding: 8px;
  }

  .file-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    text-align: left;
  }

  .file-table th {
    background-color: #f1f5f9;
    color: #475569;
    font-weight: 600;
    padding: 10px 12px;
    border-bottom: 2px solid #e2e8f0;
  }

  .file-table td {
    padding: 10px 12px;
    border-bottom: 1px solid #f1f5f9;
    color: #334155;
    vertical-align: middle;
  }

  .file-table tr:hover { background-color: #f8fafc; }

  .icon-ext-box {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }
  .icon-ext-label {
    font-size: 11px;
    font-weight: 700;
    color: #475569;
    text-transform: uppercase;
  }

  .empty-file-msg { text-align: center; color: #94a3b8; padding: 20px 0; }
  .status-new {
    color: #2563eb;
    font-weight: 600;
    font-size: 11px;
    background: #eff6ff;
    padding: 2px 6px;
    border-radius: 4px;
    margin-left: 6px;
  }
  
  .mode-badge {
    font-size: 11px;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
  }
  .mode-badge-edit { background: #fef3c7; color: #d97706; }
  .mode-badge-view { background: #e0f2fe; color: #0284c7; }

  /* 신규추가 / 삭제 상태 요약 태그 스타일 */
  .state-summary-bar {
    font-size: 11px;
    color: #64748b;
    margin-left: 8px;
    display: inline-flex;
    gap: 6px;
    align-items: center;
  }
  .state-tag-c { background: #eff6ff; color: #1d4ed8; padding: 1px 6px; border-radius: 3px; border: 1px solid #bfdbfe; font-weight: 600; }
  .state-tag-u { background: #f1f5f9; color: #475569; padding: 1px 6px; border-radius: 3px; border: 1px solid #e2e8f0; }
  .state-tag-d { background: #fef2f2; color: #dc2626; padding: 1px 6px; border-radius: 3px; border: 1px solid #fecaca; font-weight: 600; }
</style>

<div id="${compName}_container" class="file-component-container" data-comp-name="${compName}" data-form-id="${formId}" data-mode="${mode}">
  <!-- 1. 상단 툴바 헤더 (제목, 모드 표시, 파일 개수 및 신규/수정/삭제 상태 요약) -->
  <div class="file-toolbar">
    <div class="title">
      <span>${compTitle}</span>
      <span id="${compName}_modeBadge" class="mode-badge ${mode eq 'VIEW' ? 'mode-badge-view' : 'mode-badge-edit'}">[${mode}]</span>
      <span id="${compName}_fileCountBadge" style="font-size: 12px; color: #64748b; font-weight: normal;">(총 0개)</span>
      <!-- ★ 신규추가, 기존/수정, 삭제 상태별 개수 요약 바 -->
      <span id="${compName}_stateSummaryBar" class="state-summary-bar"></span>
    </div>
    <div class="file-btn-group">
      <button type="button" id="${compName}_btnAdd" class="btn-file-action btn-add-file" style="${mode eq 'VIEW' ? 'display:none;' : ''}"
              onclick="FileComponentManager.getInstance('${compName}').triggerAddFile()">
        💻 내 PC
      </button>
      <button type="button" id="${compName}_btnDelete" class="btn-file-action btn-delete-file" style="${mode eq 'VIEW' ? 'display:none;' : ''}"
              onclick="FileComponentManager.getInstance('${compName}').deleteSelectedFiles()">
        🗑️ 삭제
      </button>
      <input type="file" id="${compName}_fallbackFileInput" style="display:none;" multiple onchange="FileComponentManager.getInstance('${compName}').handleFallbackUpload(this)" />
    </div>
  </div>

  <!-- 2. Innorix 영역 -->
  <div id="${compName}_innorixBox" class="innorix-wrapper" style="display:none;">
    <div style="font-size: 12px; color: #64748b; text-align: center;">[Innorix Component Active Area: ${compName}]</div>
  </div>

  <!-- 3. 파일 목록 테이블 -->
  <table class="file-table">
    <thead>
      <tr>
        <th id="${compName}_thChk" style="width: 40px; text-align: center; ${mode eq 'VIEW' ? 'display:none;' : ''}">
          <input type="checkbox" id="${compName}_chkAllFiles" onchange="FileComponentManager.getInstance('${compName}').toggleAllCheckboxes(this)" />
        </th>
        <th style="width: 100px;">파일유형</th>
        <th>파일명</th>
        <th style="width: 160px;">등록일</th>
        <th style="width: 110px;">파일 크기</th>
        <th id="${compName}_thDown" style="width: 100px; text-align: center; ${mode eq 'EDIT' ? 'display:none;' : ''}">다운로드</th>
      </tr>
    </thead>
    <tbody id="${compName}_tableBody">
      <tr>
        <td colspan="5" class="empty-file-msg">등록된 첨부파일이 없습니다.</td>
      </tr>
    </tbody>
  </table>

  <!-- 4. Hidden Input -->
  <input type="hidden" id="${compName}_fileListJson" name="${compName}_fileList" value="[]" />
</div>

<script>
/**
 * ============================================================================================
 * 📌 전역 파일 컴포넌트 매니저 (FileComponentManager)
 * ============================================================================================
 */
if (typeof window.FileComponentManager === 'undefined') {
    window.FileComponentManager = (function() {
        const instances = {};

        function register(name, instance) {
            instances[name] = instance;
        }

        function getInstance(name) {
            return instances[name];
        }

        function load(name, targetId) {
            const inst = getInstance(name);
            if (inst) inst.load(targetId);
        }

        function loadAll(formId, targetIdMap) {
            for (let name in instances) {
                const inst = instances[name];
                if (!formId || inst.formId === formId) {
                    let targetId = targetIdMap;
                    if (typeof targetIdMap === 'object' && targetIdMap !== null) {
                        targetId = targetIdMap[name] || targetIdMap['default'];
                    }
                    inst.load(targetId);
                }
            }
        }

        function setMode(name, mode) {
            const inst = getInstance(name);
            if (inst) inst.setMode(mode);
        }

        function setModeAll(formId, mode) {
            for (let name in instances) {
                const inst = instances[name];
                if (!formId || inst.formId === formId) {
                    inst.setMode(mode);
                }
            }
        }

        function getFileList(name) {
            const inst = getInstance(name);
            return inst ? inst.getFileList() : [];
        }

        function getAllFileList(formId) {
            let combinedList = [];
            for (let name in instances) {
                const inst = instances[name];
                if (!formId || inst.formId === formId) {
                    combinedList = combinedList.concat(inst.getFileList());
                }
            }
            return combinedList;
        }

        /**
         * ============================================================================================
         * 📌 [★ 공통 기능] 신규추가(C), 기존/수정(U), 삭제(D) 상태별 파일 개수 파악 함수
         * ============================================================================================
         * @param {Array|String} target - 분석할 파일 객체 배열(FileMetaDto[]) 또는 컴포넌트 name(String) 또는 Form ID(String)
         * @return {Object} 상태별 개수 집계 객체
         * 
         * 반환 객체 구조 예시:
         * {
         *    totalCount: 5,        // 전체 관리 중인 파일 총 개수 (C + U + D)
         *    activeCount: 4,       // 현재 화면에 보이는 활성 파일 개수 (C + U)
         *    createdCount: 2,      // 신규 추가된 파일 개수 (rowState == 'C')
         *    updatedCount: 2,      // 기존 저장되어 유지/수정된 파일 개수 (rowState == 'U')
         *    deletedCount: 1,      // 삭제 선택된 파일 개수 (rowState == 'D')
         *    byState: {
         *        C: 2, // 신규추가 개수
         *        U: 2, // 기존/유지 개수
         *        D: 1  // 삭제 개수
         *    }
         * }
         */
        function calculateFileStateCounts(target) {
            let list = [];

            if (Array.isArray(target)) {
                list = target;
            } else if (typeof target === 'string') {
                if (instances[target]) {
                    list = instances[target].getFileList();
                } else {
                    list = getAllFileList(target);
                }
            } else {
                list = getAllFileList();
            }

            const result = {
                totalCount: list.length,
                activeCount: 0,
                createdCount: 0, // C (신규추가)
                updatedCount: 0, // U (기존/수정)
                deletedCount: 0, // D (삭제)
                byState: {
                    C: 0,
                    U: 0,
                    D: 0
                }
            };

            list.forEach(file => {
                let state = (file && file.rowState) ? file.rowState.toUpperCase() : 'U';

                if (state === 'C' || state === 'CREATE' || state === 'INSERT') {
                    result.createdCount++;
                    result.byState.C++;
                    result.activeCount++;
                } else if (state === 'D' || state === 'DELETE') {
                    result.deletedCount++;
                    result.byState.D++;
                } else {
                    // 기본값 U (Update/Unchanged)
                    result.updatedCount++;
                    result.byState.U++;
                    result.activeCount++;
                }
            });

            return result;
        }

        // 특정 컴포넌트(name)의 C, U, D 상태별 개수 집계
        function getFileStateCounts(name) {
            return calculateFileStateCounts(name);
        }

        // 특정 Form ID 소속 전체 파일의 C, U, D 상태별 개수 집계
        function getAllFileStateCounts(formId) {
            return calculateFileStateCounts(formId);
        }

        /**
         * [추가 공통 기능] 파일 확장자/카테고리별 개수 집계 함수
         */
        function calculateFileTypeCounts(target) {
            let list = [];
            if (Array.isArray(target)) list = target;
            else if (typeof target === 'string') list = instances[target] ? instances[target].getFileList() : getAllFileList(target);
            else list = getAllFileList();

            const activeFiles = list.filter(f => f && f.rowState !== 'D');
            const counts = {
                totalCount: activeFiles.length,
                totalSizeBytes: 0,
                formattedTotalSize: "0 B",
                byCategory: { excel: 0, word: 0, ppt: 0, pdf: 0, image: 0, zip: 0, text: 0, other: 0 },
                byExtension: {}
            };

            activeFiles.forEach(file => {
                const ext = (file.fileExtension || '').toLowerCase();
                const size = file.fileSize || 0;
                counts.totalSizeBytes += size;

                if (ext) counts.byExtension[ext] = (counts.byExtension[ext] || 0) + 1;

                if (['xlsx', 'xls', 'csv'].includes(ext)) counts.byCategory.excel++;
                else if (['docx', 'doc', 'hwp', 'hwpx'].includes(ext)) counts.byCategory.word++;
                else if (['pptx', 'ppt', 'show'].includes(ext)) counts.byCategory.ppt++;
                else if (['pdf'].includes(ext)) counts.byCategory.pdf++;
                else if (['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg'].includes(ext)) counts.byCategory.image++;
                else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) counts.byCategory.zip++;
                else if (['txt', 'json', 'xml', 'html', 'js', 'css', 'java', 'sql', 'md'].includes(ext)) counts.byCategory.text++;
                else counts.byCategory.other++;
            });

            counts.formattedTotalSize = formatByteSize(counts.totalSizeBytes);
            return counts;
        }

        function formatByteSize(bytes) {
            if (!bytes || bytes <= 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        return {
            register: register,
            getInstance: getInstance,
            load: load,
            loadAll: loadAll,
            setMode: setMode,
            setModeAll: setModeAll,
            getFileList: getFileList,
            getAllFileList: getAllFileList,
            
            // ★ [신규 추가, 기존/수정, 삭제] 상태별 개수 집계 API
            calculateFileStateCounts: calculateFileStateCounts,
            getFileStateCounts: getFileStateCounts,
            getAllFileStateCounts: getAllFileStateCounts,

            // 확장자/카테고리별 집계 API
            calculateFileTypeCounts: calculateFileTypeCounts,
            getFileTypeCounts: function(name) { return calculateFileTypeCounts(name); },
            getAllFileTypeCounts: function(formId) { return calculateFileTypeCounts(formId); }
        };
    })();
}

/**
 * ============================================================================================
 * 📌 개별 파일 컴포넌트 인스턴스 생성 및 상태 관리
 * ============================================================================================
 */
(function() {
    const compName = "${compName}";
    const formId = "${formId}";

    const instance = {
        name: compName,
        formId: formId,
        mode: "${mode}",
        fileList: [],

        setMode: function(newMode) {
            this.mode = (newMode || 'EDIT').toUpperCase();
            this.applyModeUI();
            this.renderTable();
        },

        applyModeUI: function() {
            const btnAdd = document.getElementById(compName + '_btnAdd');
            const btnDelete = document.getElementById(compName + '_btnDelete');
            const thChk = document.getElementById(compName + '_thChk');
            const thDown = document.getElementById(compName + '_thDown');
            const modeBadge = document.getElementById(compName + '_modeBadge');

            if (modeBadge) {
                modeBadge.textContent = '[' + this.mode + ']';
                modeBadge.className = 'mode-badge ' + (this.mode === 'VIEW' ? 'mode-badge-view' : 'mode-badge-edit');
            }

            if (this.mode === 'VIEW') {
                if (btnAdd) btnAdd.style.display = 'none';
                if (btnDelete) btnDelete.style.display = 'none';
                if (thChk) thChk.style.display = 'none';
                if (thDown) thDown.style.display = '';
            } else {
                if (btnAdd) btnAdd.style.display = '';
                if (btnDelete) btnDelete.style.display = '';
                if (thChk) thChk.style.display = '';
                if (thDown) thDown.style.display = 'none';
            }
        },

        initInnorix: function() {
            if (this.mode === 'EDIT' && typeof innorix !== 'undefined') {
                const box = document.getElementById(compName + '_innorixBox');
                if (box) box.style.display = 'block';
            }
        },

        load: function(targetId) {
            if (!targetId) {
                this.renderTable();
                return;
            }
            fetch('/api/files?targetId=' + targetId + '&category=' + encodeURIComponent(compName))
                .then(res => res.json())
                .then(data => {
                    this.fileList = (data || []).map(f => {
                        f.rowState = "U";
                        f.category = compName;
                        return f;
                    });
                    this.syncHiddenFields();
                    this.renderTable();
                })
                .catch(err => console.error('[' + compName + '] 파일 조회 중 오류:', err));
        },

        triggerAddFile: function() {
            if (this.mode === 'VIEW') return;
            if (this.innorixObj) {
                this.innorixObj.openFileDialog();
            } else {
                document.getElementById(compName + '_fallbackFileInput').click();
            }
        },

        handleFallbackUpload: function(inputEl) {
            if (this.mode === 'VIEW') return;
            const files = inputEl.files;
            if (!files || files.length === 0) return;

            Array.from(files).forEach(file => {
                const formData = new FormData();
                formData.append("file", file);
                formData.append("category", compName);

                fetch('/api/files/upload', {
                    method: 'POST',
                    body: formData
                })
                .then(async res => {
                    if (!res.ok) {
                        const errorJson = await res.json().catch(() => null);
                        const msg = (errorJson && errorJson.error) ? errorJson.error : ('HTTP ' + res.status);
                        throw new Error(msg);
                    }
                    return res.json();
                })
                .then(fileMeta => {
                    this.onFileUploadCompleted(fileMeta);
                })
                .catch(err => {
                    console.warn('서버 업로드 응답 예외:', err.message);
                    const ext = file.name.includes('.') ? file.name.substring(file.name.lastIndexOf('.') + 1).toLowerCase() : '';
                    const fallbackMeta = {
                        fileId: Date.now() + Math.floor(Math.random() * 1000),
                        category: compName,
                        rowState: "C",
                        originalName: file.name,
                        savedName: "temp_" + file.name,
                        fileExtension: ext,
                        fileSize: file.size,
                        formattedSize: this.formatSize(file.size),
                        contentType: file.type || "application/octet-stream",
                        regDate: new Date().toISOString().replace('T', ' ').substring(0, 19),
                        uploadStatus: "TEMP_UPLOADED"
                    };
                    this.onFileUploadCompleted(fallbackMeta);
                });
            });
            inputEl.value = '';
        },

        onFileUploadCompleted: function(fileMeta) {
            fileMeta.rowState = "C"; // ★ 신규 추가 상태 태깅
            fileMeta.category = compName;
            this.fileList.push(fileMeta);
            this.syncHiddenFields();
            this.renderTable();
        },

        deleteSelectedFiles: function() {
            if (this.mode === 'VIEW') return;
            
            const visibleRows = Array.from(document.querySelectorAll('#' + compName + '_tableBody tr[data-file-id]'));
            const checkedRows = visibleRows.filter(tr => tr.querySelector('.chk-file-item:checked'));

            if (checkedRows.length === 0) {
                alert('삭제할 파일을 선택해주세요.');
                return;
            }

            if (!confirm(checkedRows.length + '개의 파일을 목록에서 삭제하시겠습니까?')) return;

            checkedRows.forEach(tr => {
                const fId = tr.dataset.fileId;
                const fileObj = this.fileList.find(f => String(f.fileId) === String(fId));

                if (fileObj) {
                    if (fileObj.rowState === "C") {
                        // 신규 업로드 항목(C)은 배열에서 즉시 제거
                        this.fileList = this.fileList.filter(f => String(f.fileId) !== String(fId));
                    } else {
                        // 기존 저장 항목(U)은 rowState = "D" (삭제)로 변경
                        fileObj.rowState = "D";
                    }
                }
            });

            const chkAll = document.getElementById(compName + '_chkAllFiles');
            if (chkAll) chkAll.checked = false;

            this.syncHiddenFields();
            this.renderTable();
        },

        toggleAllCheckboxes: function(masterChk) {
            const items = document.querySelectorAll('#' + compName + '_tableBody .chk-file-item');
            items.forEach(chk => chk.checked = masterChk.checked);
        },

        // 테이블 렌더링 및 C, U, D 상태 요약 바 업데이트
        renderTable: function() {
            const tbody = document.getElementById(compName + '_tableBody');
            const badgeEl = document.getElementById(compName + '_fileCountBadge');
            const stateSummaryBar = document.getElementById(compName + '_stateSummaryBar');
            if (!tbody) return;

            tbody.innerHTML = '';
            
            // 화면 표시용 활성 파일 (rowState !== 'D')
            const activeFiles = this.fileList.filter(f => f.rowState !== 'D');

            if (badgeEl) badgeEl.textContent = '(' + '총 ' + activeFiles.length + '개' + ')';

            // ★ 공통 함수(calculateFileStateCounts)를 호출하여 C(신규추가), U(기존/수정), D(삭제) 개수 상단 요약 바 표시
            if (stateSummaryBar) {
                const stateCounts = FileComponentManager.calculateFileStateCounts(this.fileList);
                let stateHtml = '';

                if (stateCounts.createdCount > 0) {
                    stateHtml += `<span class="state-tag-c">➕ 신규 ${stateCounts.createdCount}개</span>`;
                }
                if (stateCounts.updatedCount > 0) {
                    stateHtml += `<span class="state-tag-u">💾 기존 ${stateCounts.updatedCount}개</span>`;
                }
                if (stateCounts.deletedCount > 0) {
                    stateHtml += `<span class="state-tag-d">🗑️ 삭제 ${stateCounts.deletedCount}개</span>`;
                }
                stateSummaryBar.innerHTML = stateHtml;
            }

            const isView = (this.mode === 'VIEW');

            if (activeFiles.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" class="empty-file-msg">등록된 첨부파일이 없습니다.</td></tr>`;
                return;
            }

            activeFiles.forEach((file, idx) => {
                const tr = document.createElement('tr');
                tr.setAttribute('data-file-id', file.fileId);

                const ext = (file.fileExtension || 'FILE').toLowerCase();
                const iconSvg = this.getFileIconSvg(ext);

                let rowHtml = '';

                if (!isView) {
                    rowHtml += `
                        <td style="text-align: center;">
                            <input type="checkbox" class="chk-file-item" />
                        </td>
                    `;
                }

                rowHtml += `
                    <td>
                        <div class="icon-ext-box">
                            \${iconSvg}
                            <span class="icon-ext-label">\${ext.toUpperCase()}</span>
                        </div>
                    </td>
                    <td>
                        \${this.escapeHtml(file.originalName)}
                        \${file.rowState === 'C' ? '<span class="status-new">신규</span>' : ''}
                    </td>
                    <td>\${file.regDate || '-'}</td>
                    <td>\${file.formattedSize || this.formatSize(file.fileSize)}</td>
                `;

                if (isView) {
                    rowHtml += `
                        <td style="text-align: center;">
                            \${file.fileId ? `
                                <button type="button" class="btn-file-action btn-download-file" style="padding: 3px 10px; font-size:12px;" 
                                        onclick="FileComponentManager.getInstance('\${compName}').downloadFile(\${file.fileId})">
                                  💾 다운로드
                                </button>
                            ` : '<span style="color:#94a3b8; font-size:11px;">다운로드 불가</span>'}
                        </td>
                    `;
                }

                tr.innerHTML = rowHtml;
                tbody.appendChild(tr);
            });
        },

        getFileIconSvg: function(ext) {
            ext = (ext || '').toLowerCase();
            if (['xlsx', 'xls', 'csv'].includes(ext)) {
                return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M14 2H6C4.89 2 4 2.89 4 4V20C4 21.11 4.89 22 6 22H18C19.11 22 20 21.11 20 20V8L14 2Z" fill="#16a34a" fill-opacity="0.15" stroke="#16a34a" stroke-width="2"/><path d="M14 2V8H20" stroke="#16a34a" stroke-width="2"/><path d="M9.5 12L14.5 17M14.5 12L9.5 17" stroke="#15803d" stroke-width="2"/></svg></span>`;
            }
            if (['docx', 'doc', 'hwp', 'hwpx'].includes(ext)) {
                return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M14 2H6C4.89 2 4 2.89 4 4V20C4 21.11 4.89 22 6 22H18C19.11 22 20 21.11 20 20V8L14 2Z" fill="#2563eb" fill-opacity="0.15" stroke="#2563eb" stroke-width="2"/><path d="M14 2V8H20" stroke="#2563eb" stroke-width="2"/><path d="M9 13L10.5 17.5L12 13.5L13.5 17.5L15 13" stroke="#1d4ed8" stroke-width="2"/></svg></span>`;
            }
            if (['pptx', 'ppt', 'show'].includes(ext)) {
                return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M14 2H6C4.89 2 4 2.89 4 4V20C4 21.11 4.89 22 6 22H18C19.11 22 20 21.11 20 20V8L14 2Z" fill="#ea580c" fill-opacity="0.15" stroke="#ea580c" stroke-width="2"/><path d="M14 2V8H20" stroke="#ea580c" stroke-width="2"/><path d="M10 12H13.5C14.33 12 15 12.67 15 13.5C15 14.33 14.33 15 13.5 15H10V17.5" stroke="#c2410c" stroke-width="2"/></svg></span>`;
            }
            if (['pdf'].includes(ext)) {
                return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M14 2H6C4.89 2 4 2.89 4 4V20C4 21.11 4.89 22 6 22H18C19.11 22 20 21.11 20 20V8L14 2Z" fill="#dc2626" fill-opacity="0.15" stroke="#dc2626" stroke-width="2"/><path d="M14 2V8H20" stroke="#dc2626" stroke-width="2"/><text x="8.2" y="16.2" font-size="7" font-weight="bold" fill="#b91c1c">PDF</text></svg></span>`;
            }
            if (['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg'].includes(ext)) {
                return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="3" fill="#7c3aed" fill-opacity="0.15" stroke="#7c3aed" stroke-width="2"/><circle cx="8.5" cy="8.5" r="1.5" fill="#7c3aed"/><path d="M21 15L16 10L5 21" stroke="#6d28d9" stroke-width="2"/></svg></span>`;
            }
            return `<span><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M14 2H6C4.89 2 4 2.89 4 4V20C4 21.11 4.89 22 6 22H18C19.11 22 20 21.11 20 20V8L14 2Z" fill="#94a3b8" fill-opacity="0.15" stroke="#64748b" stroke-width="2"/><path d="M14 2V8H20" stroke="#64748b" stroke-width="2"/></svg></span>`;
        },

        downloadFile: function(fileId) {
            window.location.href = '/api/files/download/' + fileId;
        },

        syncHiddenFields: function() {
            const listHidden = document.getElementById(compName + '_fileListJson');
            if (listHidden) listHidden.value = JSON.stringify(this.fileList);
        },

        getFileList: function() {
            return this.fileList;
        },

        // 인스턴스 전용 C, U, D 상태별 개수 집계 함수
        getStateCounts: function() {
            return FileComponentManager.calculateFileStateCounts(this.fileList);
        },

        formatSize: function(bytes) {
            if (!bytes) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        },

        escapeHtml: function(str) {
            if (!str) return '';
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }
    };

    FileComponentManager.register(compName, instance);
    instance.initInnorix();
})();
</script>
